/*!
 * UI development toolkit for HTML5 (OpenUI5)
 * (c) Copyright 2009-2018 SAP SE or an SAP affiliate company.
 * Licensed under the Apache License, Version 2.0 - see LICENSE.txt.
 */
sap.ui.define([],function(){"use strict";var h=function(s){var i=s.length,H=0;while(i--){H=(H<<5)-H+s.charCodeAt(i);H=H&H;}return H;};return h;});
